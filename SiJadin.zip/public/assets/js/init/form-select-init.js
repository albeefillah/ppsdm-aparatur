"use strict";
$(document).ready(function() {    

    /* -----  Form Select - Select2 ----- */

    $('.xp-select2-single').select2();
    $('.xp-select2-multi-select').select2({
        placeholder: 'Choose',
    });

   


});