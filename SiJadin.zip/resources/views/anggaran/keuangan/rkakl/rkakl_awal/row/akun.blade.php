<tr>
    <td align="center">{{ $item['kode'] }}</td>
    <td>{{ $item['deskripsi'] }}</td>
    <td align="right">{{ number_format( $item['pagu'], 0, ",", ".") }}</td>
    <td></td>
</tr>